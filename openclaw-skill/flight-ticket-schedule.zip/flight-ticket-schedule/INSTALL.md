# Install (OpenClaw)

1) Unzip this folder into your OpenClaw managed skills directory:

```bash
unzip flight-ticket-schedule.zip -d ~/.openclaw/skills/
```

This will create:

- `~/.openclaw/skills/flight-ticket-schedule/`

2) Create your env file:

```bash
cd ~/.openclaw/skills/flight-ticket-schedule
cp .env.example .env
# edit .env and set DUFFEL_ACCESS_TOKEN
```

3) Run (recommended: uv)

```bash
cd ~/.openclaw/skills/flight-ticket-schedule
uv run flight_search.py --origin LHR --destination JFK --dep_date 2026-05-01 --limit 5
uv run deep_link_generator.py --origin LHR --destination JFK --dep_date 2026-05-01 --adults 2 --child_ages "5,12"
```

4) Refresh skills

If the skill doesn't appear immediately, restart the gateway or start a new session.
