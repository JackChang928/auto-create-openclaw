# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "requests",
#     "python-dotenv",
# ]
# ///
import os
import argparse
import json
import requests
from datetime import datetime, timedelta
from dotenv import load_dotenv

load_dotenv()
token = os.getenv("DUFFEL_ACCESS_TOKEN")
if not token:
    print(json.dumps({"error": "找不到 DUFFEL_ACCESS_TOKEN，請檢查 .env 檔案"}))
    exit(1)

HEADERS = {
    "Authorization": f"Bearer {token}",
    "Duffel-Version": "v2",
    "Accept-Encoding": "gzip",
    "Content-Type": "application/json"
}

def resolve_place(query_str):
    if len(query_str) == 3 and query_str.encode().isalpha():
        return query_str.upper()
    try:
        url = f"https://api.duffel.com/places/suggestions?query={query_str}"
        response = requests.get(url, headers=HEADERS, timeout=10)
        if response.status_code == 200:
            for s in response.json().get('data', []):
                if s.get('type') in ["airport", "city"] and s.get('iata_code'):
                    return s['iata_code']
    except Exception:
        pass
    return query_str.upper()

def search_single_date(origin, destination, dep_date, adults=1, children=0, cabin_class="economy", target_arrival_date=None, force_direct=False):
    results = []
    
    passengers = [{"type": "adult"} for _ in range(adults)]
    passengers.extend([{"age": 8} for _ in range(children)])

    try:
        payload = {
            "data": {
                "passengers": passengers,
                "cabin_class": cabin_class,
                "supplier_timeout": 10000,
                "slices": [{
                    "origin": origin,
                    "destination": destination,
                    "departure_date": dep_date
                }]
            }
        }
        
        if force_direct:
            payload["data"]["max_connections"] = 0
            
        url = "https://api.duffel.com/air/offer_requests?return_offers=true"
        response = requests.post(url, headers=HEADERS, json=payload, timeout=20)
        
        if response.status_code not in [200, 201]:
            print(f"\n🚨 [API 錯誤] 狀態碼 {response.status_code} | 詳情: {response.text}\n")
            return results 

        offers = response.json().get('data', {}).get('offers', [])
        
        for offer in offers:
            if not offer.get('slices') or not offer['slices'][0].get('segments'):
                continue
                
            flight = offer['slices'][0]['segments'][0]
            arr_time = flight['arriving_at']
            
            if target_arrival_date and not arr_time.startswith(target_arrival_date):
                continue
            
            op_carrier = flight.get('operating_carrier') or flight.get('marketing_carrier')
            flight_num = flight.get('operating_carrier_flight_number') or flight.get('marketing_carrier_flight_number')
            
            results.append({
                "airline": op_carrier.get('name', 'Unknown Airline'),
                "flight_number": f"{op_carrier.get('iata_code', '')}{flight_num}",
                "departure_local": flight['departing_at'],
                "arrival_local": arr_time,
                "price": f"{offer['total_amount']} {offer['total_currency']}",
                "cabin_class": cabin_class,
                "co2_emissions_kg": offer.get('total_emissions_kg')
            })
            
    except requests.exceptions.RequestException as e:
        print(f"\n🚨 [網路連線錯誤] {str(e)}\n")
    except Exception as e:
        print(f"\n🚨 [資料解析錯誤] {str(e)}\n")
        
    return results

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--origin", required=True)
    parser.add_argument("--destination", required=True)
    parser.add_argument("--dep_date", help="出發日期 YYYY-MM-DD")
    parser.add_argument("--arr_date", help="抵達日期 YYYY-MM-DD")
    parser.add_argument("--date_range", help="出發區間 YYYY-MM-DD:YYYY-MM-DD")
    parser.add_argument("--adults", type=int, default=1)
    parser.add_argument("--children", type=int, default=0)
    parser.add_argument("--cabin_class", default="economy", choices=["economy", "premium_economy", "business", "first"])
    
    # 🔥 新增 limit 參數，預設值為 5
    parser.add_argument("--limit", type=int, default=5, help="回傳的航班數量上限 (輸入 0 代表全拿)")
    
    args = parser.parse_args()
    
    real_origin = resolve_place(args.origin)
    real_dest = resolve_place(args.destination)
    all_flights = []
    
    if args.date_range:
        start_str, end_str = args.date_range.split(":")
        start_date = datetime.strptime(start_str, "%Y-%m-%d")
        end_date = datetime.strptime(end_str, "%Y-%m-%d")
        
        current_date = start_date
        while current_date <= end_date:
            all_flights.extend(search_single_date(
                real_origin, real_dest, current_date.strftime("%Y-%m-%d"), 
                args.adults, args.children, args.cabin_class, force_direct=True
            ))
            current_date += timedelta(days=1)
            
    elif args.arr_date:
        all_flights.extend(search_single_date(
            real_origin, real_dest, args.arr_date, 
            args.adults, args.children, args.cabin_class, target_arrival_date=args.arr_date
        ))
        
    elif args.dep_date:
        all_flights.extend(search_single_date(
            real_origin, real_dest, args.dep_date, 
            args.adults, args.children, args.cabin_class
        ))
        
    else:
        print(json.dumps({"error": "必須提供 dep_date, arr_date 或 date_range 之一"}))
        return

    # 🔥 依價格排序並根據 limit 截斷資料
    sorted_flights = sorted(all_flights, key=lambda x: float(x['price'].split()[0]))
    if args.limit > 0:
        final_flights = sorted_flights[:args.limit]
    else:
        final_flights = sorted_flights # 若為 0 則不設限

    output = {
        "search_query": f"{real_origin} -> {real_dest}",
        "passengers": f"{args.adults} Adults, {args.children} Children",
        "cabin_class": args.cabin_class,
        "total_results": len(all_flights),      # 總共找到的航班數
        "returned_results": len(final_flights), # 實際吐出的航班數
        "flights": final_flights
    }
    print(json.dumps(output, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()