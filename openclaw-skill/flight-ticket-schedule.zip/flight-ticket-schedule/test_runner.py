import subprocess
import json

def run_test(case_name, command):
    print(f"\n{'='*60}")
    print(f"🚀 {case_name}")
    print(f"💻 執行指令: {' '.join(command)}")
    print(f"{'-'*60}")
    
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        # 由於我們加入了錯誤 print()，如果 stdout 混雜了非 JSON 的字串，嘗試分離
        output_lines = result.stdout.strip().split('\n')
        for line in output_lines:
            if line.startswith("🚨"):
                print(line) # 印出錯誤訊息
                
        # 嘗試解析最後一塊 JSON
        try:
            # 尋找 JSON 結構的開頭 '{'
            json_start = result.stdout.find('{')
            if json_start != -1:
                parsed_json = json.loads(result.stdout[json_start:])
                print(json.dumps(parsed_json, ensure_ascii=False, indent=2))
        except json.JSONDecodeError:
            print(f"⚠️ 輸出非有效 JSON:\n{result.stdout}")
            
    except subprocess.CalledProcessError as e:
        print(f"❌ 執行失敗: {e.stderr}")

if __name__ == "__main__":
    # ✈️ 引擎一：Duffel 航班檢索測試
    cases = [
        {
            "name": "Case 1: [檢索] 基礎搜尋 (出發地、目的地、出發時間)",
            "cmd": ["uv", "run", "flight_search.py", "--origin", "LHR", "--destination", "JFK", "--dep_date", "2026-05-01"]
        },
        {
            "name": "Case 2: [檢索] 依抵達時間查詢 (驗證 2大3小 家庭人數)",
            "cmd": ["uv", "run", "flight_search.py", "--origin", "LHR", "--destination", "JFK", "--arr_date", "2026-05-01", "--adults", "2", "--children", "3"]
        },
        {
            "name": "Case 3: [檢索] 地點名稱智能解析 (London 自動轉 LHR)",
            "cmd": ["uv", "run", "flight_search.py", "--origin", "London", "--destination", "JFK", "--arr_date", "2026-05-01"]
        },
        {
            "name": "Case 4: [檢索] 彈性區間搜尋 (三天範圍直飛)",
            "cmd": ["uv", "run", "flight_search.py", "--origin", "LHR", "--destination", "JFK", "--date_range", "2026-05-01:2026-05-03"]
        },
        {
            "name": "Case 5: [檢索] 進階過濾 - 指定商務艙 (Business Class)",
            "cmd": ["uv", "run", "flight_search.py", "--origin", "LHR", "--destination", "JFK", "--dep_date", "2026-05-01", "--cabin_class", "business"]
        },
        {
            "name": "Case 6: [檢索] 數量控制 - 嚴格限制 (僅顯示前 2 筆最便宜)",
            "cmd": ["uv", "run", "flight_search.py", "--origin", "LHR", "--destination", "JFK", "--dep_date", "2026-05-01", "--limit", "2"]
        },
        {
            "name": "Case 7: [檢索] 貪婪模式 - 無上限全抓 (測試底層撈取極限)",
            "cmd": ["uv", "run", "flight_search.py", "--origin", "LHR", "--destination", "JFK", "--dep_date", "2026-05-01", "--limit", "0"]
        },
        
        # 🔗 引擎二：全網 Deep Link 生成測試
        {
            "name": "Case 8: [導購] 基礎單人經濟艙連結生成 (隱藏兒童參數)",
            "cmd": ["python3", "deep_link_generator.py", "--origin", "LHR", "--destination", "JFK", "--dep_date", "2026-05-01"]
        },
        {
            "name": "Case 9: [導購] 家庭出遊 2大3小 (驗證 Skyscanner %7C 編碼與 Booking 逗號編碼)",
            "cmd": ["python3", "deep_link_generator.py", "--origin", "LHR", "--destination", "JFK", "--dep_date", "2026-05-01", "--adults", "2", "--children", "3"]
        },
        {
            "name": "Case 10: [導購] 奢華商務艙 + 中文地名支援 (驗證 Trip/Ctrip 艙等對應與飛豬 URL Encode)",
            "cmd": ["python3", "deep_link_generator.py", "--origin", "LHR", "--destination", "JFK", "--dep_date", "2026-05-01", "--adults", "3", "--children", "2", "--cabin_class", "business", "--origin_zh", "倫敦", "--dest_zh", "紐約"]
        }
    ]
    
    for case in cases:
        run_test(case["name"], case["cmd"])