# /// script
# requires-python = ">=3.10"
# ///
import argparse
import json
import urllib.parse
from datetime import datetime

def generate_all_flight_links(
    origin: str, 
    destination: str, 
    date_str: str, 
    adults: int = 1, 
    children: int = 0, 
    child_ages: str = "", 
    cabin_class: str = "economy", 
    origin_zh: str = "", 
    dest_zh: str = ""
):
    """
    動態生成各大 OTA 平台的機票訂購連結。
    支援兒童年齡精確指定與防呆預設機制。
    """
    origin_lower = origin.lower()
    dest_lower = destination.lower()
    origin_upper = origin.upper()
    dest_upper = destination.upper()
    
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        trip_date = dt.strftime("%Y-%m-%d")         # YYYY-MM-DD
        sky_date = dt.strftime("%y%m%d")            # YYMMDD (Skyscanner)
        ez_date = dt.strftime("%d/%m/%Y").replace('/', '%2F') # DD%2FMM%2FYYYY (易遊網)
    except ValueError:
        return {"error": "日期格式錯誤，請使用 YYYY-MM-DD"}

    # 🚨 兒童年齡解析與防呆機制
    ages_list = []
    if child_ages:
        # 如果有明確指定年齡 (例: "5,12")，則切分並覆蓋 children 數量
        ages_list = [age.strip() for age in child_ages.split(",")]
        children = len(ages_list)
    elif children > 0:
        # 如果沒有指定年齡但有給數量，預設全部為 8 歲
        ages_list = ["8"] * children

    # 1. Skyscanner 艙等與兒童年齡邏輯 (使用 %7C 也就是 |)
    sky_cabin_map = {"economy": "economy", "premium_economy": "premiumeconomy", "business": "business", "first": "first"}
    sky_cabin = sky_cabin_map.get(cabin_class, "economy")
    sky_children_param = ""
    if ages_list:
        sky_children_param = f"&childrenv2={'%7C'.join(ages_list)}"

    # 2. Booking.com 艙等與兒童年齡邏輯 (使用 %2C 也就是逗號)
    booking_cabin = "PREMIUM_ECONOMY" if cabin_class == "premium_economy" else cabin_class.upper()
    booking_children_param = ""
    if ages_list:
        booking_children_param = f"&children={'%2C'.join(ages_list)}"

    # 3. 易遊網 ezTravel 艙等邏輯
    ez_cabin_map = {"economy": "economy", "premium_economy": "premiumEconomy", "business": "business", "first": "first"}
    ez_cabin = ez_cabin_map.get(cabin_class, "economy")

    # 4. Trip.com / Ctrip 底層單碼艙等
    trip_cabin_map = {"economy": "y", "premium_economy": "w", "business": "c", "first": "f"}
    trip_cabin = trip_cabin_map.get(cabin_class, "y")

    # 組合平台連結
    links = {
        "Booking.com (國際)": (
            f"https://flights.booking.com/flights/{origin_upper}.AIRPORT-{dest_upper}.AIRPORT/?"
            f"type=ONEWAY&adults={adults}{booking_children_param}&cabinClass={booking_cabin}&"
            f"from={origin_upper}.AIRPORT&to={dest_upper}.AIRPORT&depart={trip_date}&locale=zh-tw"
        ),
        
        "易遊網 ezTravel (台灣)": (
            f"https://flight.eztravel.com.tw/tickets-oneway-{origin_lower}-{dest_lower}?"
            f"outbounddate={ez_date}&adults={adults}&children={children}&infants=0&"
            f"direct=false&cabintype={ez_cabin}&dport={origin_lower}&aport={dest_lower}"
        ),

        "Trip.com (國際)": (
            f"https://tw.trip.com/flights/showfarefirst?"
            f"dcity={origin_lower}&acity={dest_lower}&ddate={trip_date}&triptype=ow&"
            f"class={trip_cabin}&quantity={adults}&children={children}&"
            f"lowpricesource=searchform&locale=zh-TW&curr=TWD"
        ),
        
        "Skyscanner (比價)": (
            f"https://www.skyscanner.com.tw/transport/flights/{origin_lower}/{dest_lower}/{sky_date}/"
            f"?adultsv2={adults}&cabinclass={sky_cabin}{sky_children_param}&rtn=0"
        ),
        
        "攜程 Ctrip (中國)": (
            f"https://flights.ctrip.com/online/list/oneway-{origin_lower}0-{dest_lower}0?"
            f"depdate={trip_date}&cabin={trip_cabin}&adult={adults}&child={children}&infant=0"
        ),
        
        "去哪兒 Qunar (中國)": f"https://flight.qunar.com/site/oneway_list.htm?searchDepartureAirport={origin_upper}&searchArrivalAirport={dest_upper}&searchDepartureTime={trip_date}"
    }
    
    # 飛豬專屬邏輯
    if origin_zh and dest_zh:
        origin_encoded = urllib.parse.quote(origin_zh)
        dest_encoded = urllib.parse.quote(dest_zh)
        links["飛豬 Fliggy (中國)"] = (
            f"https://sjipiao.fliggy.com/flight_search_result.htm?"
            f"tripType=0&"
            f"depCityName={origin_encoded}&depCity={origin_upper}&"
            f"arrCityName={dest_encoded}&arrCity={dest_upper}&"
            f"depDate={trip_date}"
        )
        
    return links

def main():
    parser = argparse.ArgumentParser(description="OTA Deep Link Generator")
    parser.add_argument("--origin", required=True, help="出發機場 IATA")
    parser.add_argument("--destination", required=True, help="抵達機場 IATA")
    parser.add_argument("--dep_date", required=True, help="出發日期 (YYYY-MM-DD)")
    parser.add_argument("--adults", type=int, default=1, help="成人數量")
    parser.add_argument("--children", type=int, default=0, help="兒童數量 (若填寫 child_ages 則會被覆蓋)")
    parser.add_argument("--child_ages", default="", help="兒童年齡，以逗號分隔 (例: 5,12)。防呆預設為 8 歲")
    parser.add_argument("--cabin_class", default="economy", choices=["economy", "premium_economy", "business", "first"])
    parser.add_argument("--origin_zh", default="", help="出發城市中文 (選填，飛豬專用)")
    parser.add_argument("--dest_zh", default="", help="抵達城市中文 (選填，飛豬專用)")
    
    args = parser.parse_args()
    
    result = generate_all_flight_links(
        origin=args.origin,
        destination=args.destination,
        date_str=args.dep_date,
        adults=args.adults,
        children=args.children,
        child_ages=args.child_ages,
        cabin_class=args.cabin_class,
        origin_zh=args.origin_zh,
        dest_zh=args.dest_zh
    )
    
    # 讓輸出的乘客資訊更精確
    passengers_str = f"{args.adults} Adults"
    if args.child_ages:
        passengers_str += f", Children ages: [{args.child_ages}]"
    elif args.children > 0:
        passengers_str += f", {args.children} Children (Default age 8)"
        
    output = {
        "parameters_used": {
            "route": f"{args.origin.upper()} -> {args.destination.upper()}",
            "date": args.dep_date,
            "passengers": passengers_str,
            "cabin": args.cabin_class
        },
        "booking_links": result
    }
    
    print(json.dumps(output, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()